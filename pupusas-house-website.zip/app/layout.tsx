export const metadata = {
  title: 'Pupusas House',
  description: 'Authentic Salvadoran Food in Aurora, CO',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body style={{margin:0,fontFamily:'Arial, sans-serif',background:'#fffbeb'}}>
        {children}
      </body>
    </html>
  );
}

'use client';
import { motion } from 'framer-motion';

export default function Page(){
  return (
    <main>
      <section style={{background:'linear-gradient(90deg,#d97706,#ea580c,#dc2626)',color:'white',padding:'80px 20px',textAlign:'center'}}>
        <motion.h1 initial={{opacity:0,y:-20}} animate={{opacity:1,y:0}} transition={{duration:0.6}} style={{fontSize:'48px',marginBottom:10}}>
          Pupusas House
        </motion.h1>
        <p style={{fontSize:20}}>Authentic Salvadoran Food • Fresh • Handmade</p>
      </section>

      <section style={{padding:'50px 20px',maxWidth:900,margin:'0 auto'}}>
        <h2>Welcome</h2>
        <p>Traditional Salvadoran dishes made fresh to order.</p>
      </section>

      <section style={{padding:'50px 20px',background:'white'}}>
        <h2 style={{textAlign:'center'}}>Menu</h2>
        <div style={{maxWidth:1000,margin:'30px auto',display:'grid',gap:30}}>
          <div>
            <h3>Aguas Frescas</h3>
            <p>Horchata Salvadoreña — $3.00 sm • $3.50 md • $4.25 lg</p>
            <p>Maracuyá / Passion Fruit — $3.75 • $3.50 • $3.50</p>
            <p>Ensalada / Mixed fruit — $3.00 • $3.50 • $4.25</p>

            <h3>Sodas</h3>
            <p>Bottle — $3.00 (Kolashampan • Coca Cola • Fanta • Tropical)</p>
            <p>Can — $2.00 (Coca Cola • Fanta • Sprite • Squirt)</p>

            <h3>Jarritos — $2.50</h3>
            <p>Mango • Fruit Punch • Piña • Mandarina • Tamarindo • Sangria • Sidra</p>

            <h3>Hot Drinks</h3>
            <p>Atol de elote — $3.75</p>
            <p>Sweet corn porridge — $3.75</p>
            <p>Chocolate — $3.00 sm • $3.50 lg</p>
            <p>Coffee — $2.00</p>
            <p>Tea — $2.00</p>
          </div>

          <div>
            <h3>Salvadorian Breakfasts</h3>
            <p>Served with beans, cream, cheese, fried plantain & 2 tortillas</p>
            <p>Desayuno #1 — Huevos revueltos con vegetales — $10.95</p>
            <p>Desayuno #2 — Huevos revueltos con chorizo — $11.50</p>
            <p>Desayuno #3 — Huevos revueltos con jamón — $10.95</p>
            <p>Desayuno #4 — Huevos estrellados — $10.95</p>

            <h3>Extras / Sides</h3>
            <p>Arroz / Rice — $2.00</p>
            <p>Frijoles / Beans — $2.00</p>
            <p>Crema / Sour Cream — $1.50</p>
            <p>Queso / Cheese — $1.50</p>
            <p>Chicharrones — $3.50</p>
            <p>Curtido — $2.00</p>
            <p>Salsa — $2.00</p>

            <h3>Desserts</h3>
            <p>Nuegados de yuca — 3 x $7.50</p>
            <p>Nuegados con chilate — 3 x $8.50</p>
            <p>Empanadas de plátano — 3 x $7.95</p>
            <p>Tamal de elote — $3.00</p>
            <p>Plátano frito — $7.50</p>
          </div>
        </div>
      </section>

      <section style={{padding:'50px 20px',textAlign:'center'}}>
        <h3>Location & Hours</h3>
        <p>2284 S Chambers Rd, Aurora, CO 80014</p>
        <p>Monday–Saturday: 9am – 9pm</p>
        <p>Sunday: 9am – 8pm</p>
      </section>

      <section style={{padding:'0 20px 60px'}}>
        <div style={{maxWidth:1000,margin:'0 auto'}}>
          <iframe
            src="https://www.google.com/maps?q=2284+S+Chambers+Rd+Aurora+CO+80014&output=embed"
            width="100%"
            height="400"
            loading="lazy"
            title="map"
          />
        </div>
      </section>

      <footer style={{background:'#111827',color:'#9ca3af',padding:20,textAlign:'center'}}>
        © {new Date().getFullYear()} Pupusas House • Aurora, Colorado
      </footer>
    </main>
  );
}
